package pp_proga2_322;


public enum EstadoSalud {
    CRITICO,
    EN_RECUPERACION,
    ESTABLE
}
