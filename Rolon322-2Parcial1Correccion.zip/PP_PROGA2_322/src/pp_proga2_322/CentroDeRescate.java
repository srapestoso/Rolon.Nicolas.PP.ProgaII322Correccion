package pp_proga2_322;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class CentroDeRescate {
    private final String nombre;
    private List<Animal> animales;

    /**
     * Constuctor de la clase CentroDeRescate
     * @param nombre del centro de rescate
     */
    public CentroDeRescate(String nombre) {
        validarDatos(nombre);
        this.nombre = nombre;
        this.animales = new ArrayList<>();
    }
    
    /**
     * Metodo que valida que el dato de tipo DOUBLE que recibe como parametro sea positivo
     * @param dato a validar
     */
    private void validarDatos(String dato){
        if(dato == null || dato.isEmpty()){
            throw new IllegalArgumentException("Dato invalido");
        }
    }
          
    /**
     * Agrega un animal a la lista
     * @param a animal para agregar a la lista
     * @throws AnimalDuplicadoException si el animal ya se encuentra en la lista
     */
    public void agregarAnimal(Animal a) throws AnimalDuplicadoException {
        Objects.requireNonNull(a);
        if(animales.contains(a)){
            throw new AnimalDuplicadoException(a.toString() + " este animal ya se encuentra en la lista");
        }
        animales.add(a);
    }
    
    /**
     * Obtiene animales en una nueva lista
     * @return Retorna una lista con los animales
     */
    public List<Animal> obtenerAnimales(){
        return new ArrayList<>(animales);
    }
    
    /**
     * Obtiene animales en una nueva lista segun el estado
     * @param estado a considerar para la nueva lista
     * @return Retorna una lista con los animales
     */
    public List<Animal> filtrarPorEstado(EstadoSalud estado){
        Objects.requireNonNull(estado);
        List<Animal> nuevaLista = new ArrayList<>();
        
        for (Animal animal : animales) {
            if(animal.getEstado().equals(estado)){
                nuevaLista.add(animal);
            }
        }
        
        return nuevaLista;
    }
    
    /**
     * Obtiene animales en una nueva lista segun el costo
     * @param costoMax a considerar para la nueva lista
     * @return Retorna una lista con los animales
     */
    
    public List<Animal> obtenerAnimalesConCostoMaximo(double costoMax){
        
        List<Animal> nuevaLista = new ArrayList<>();
        
        for (Animal animal : animales) {
            if(animal.costoDiario() <= costoMax){
                nuevaLista.add(animal);
            }
        }
        
        return nuevaLista;
    }
}
