package pp_proga2_322;

public class Reptil extends Animal implements Liberable{
    
    private static final double COSTO_BASE = 15.0;
    private final double longitud;
    
    
    /**
     * Constructor de la clase Ave
     * @param codigo identificador del animal
     * @param nombre del animal
     * @param estado de salud del animal
     * @param longitud del animal
     */
    public Reptil(String codigo, String nombre, EstadoSalud estado,double longitud) {
        super(codigo, nombre, estado);
        validarPositivo(longitud);
        this.longitud = longitud;
    }    
    
    
    /**
     * Calcula el costo diario del mamifero
     * @return double con el total
     */
    @Override
    public double costoDiario(){
        return longitud + COSTO_BASE;
    }
    
    /**
     * Realiza el proceso de liberacion
     * @return String aclarando que se está liberando el animal
     * o que no está apto para ser liberado
     */
    @Override
    public String liberar() {
        String mensaje;
        if(getEstado() == EstadoSalud.EN_RECUPERACION){
            mensaje = "Liberando a " + this.toString();
        } else {
            mensaje = this.toString() + " No está apto para ser liberado";
        }
        return mensaje;
    }

    @Override
    public String toString() {
        return super.toString() + " Reptil{" + "longitud=" + longitud + '}';
    }
    
    
}
