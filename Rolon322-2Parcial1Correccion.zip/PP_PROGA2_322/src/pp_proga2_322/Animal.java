package pp_proga2_322;

import java.util.Objects;


public abstract class Animal {
    
    private String codigo;
    private String nombre;
    private EstadoSalud estado;
    
    /***
     * Constructor de la clase Animal
     * @param codigo identificador del animal
     * @param nombre nombre del animal
     * @param estado estado de saludo del animal
     */
    public Animal(String codigo, String nombre, EstadoSalud estado) {
        validarDatos(codigo);
        validarDatos(nombre);
        Objects.requireNonNull(estado);
        this.codigo = codigo;
        this.nombre = nombre;
        this.estado = estado;
    }
    
    /**
     * Metodo para validar dato de tipo STRING que recibe como parametro
     * @param dato Dato a validar
     */
    private void validarDatos(String dato){
        if(dato == null || dato.isEmpty()){
            throw new IllegalArgumentException("Dato invalido");
        }
    }
    
    /**
     * Obtiene el nombre del animal
     * @return nombre del animal
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene el estado de salud del animal
     * @return estado de salud del animal
     */
    public EstadoSalud getEstado() {
        return estado;
    }
    
    /**
     * Obtiene el codigo del animal
     * @return estado de salud del animal
     */    
    public String getCodigo(){
        return codigo;
    }
    
    /**
     * Metodo que valida que el dato de tipo DOUBLE que recibe como parametro sea positivo
     * @param dato a validar
     */
    protected void validarPositivo(double dato){
        if(dato <= 0){
            throw new IllegalArgumentException("Dato invalido");
        }
    }

    @Override
    public String toString() {
        return "Animal{" + "codigo=" + codigo + ", nombre=" + nombre + ", estado= " + estado;
    }    
    
    
    /**
     * Metodo abstracto para calcular el costoDiario en clases derivadas
     * @return un double con el total del costo diario
     */    
    public abstract double costoDiario(); 

   
    
    @Override
    public int hashCode() {
       return Objects.hash(codigo, nombre);
    }

    @Override
    public boolean equals(Object o) {
        boolean resultado = true;
        
        if(o == null){
            resultado = false;
        }
        if(o instanceof Animal a){
            resultado = codigo.equals(((Animal) o).codigo) && nombre.equals(((Animal) o).nombre);
        }
        
        return resultado;
    }
    
}
