package pp_proga2_322;

public class Mamifero extends Animal implements Rehabilitable{
    private static final double COSTO_POR_KILO = 10.0;
    private final double peso;

    /**
     * Constructor de la clase Mamifero
     * @param codigo identificador del animal
     * @param nombre del animal
     * @param estado de salud del animal
     * @param peso del animal
     */
    public Mamifero(String codigo, String nombre, EstadoSalud estado,double peso) {
        super(codigo, nombre, estado);
        validarPositivo(peso);
        this.peso = peso;
    }    
    
    /**
     * Calcula el costo diario del mamifero
     * @return double con el total
     */
    @Override
    public double costoDiario(){
        return peso * COSTO_POR_KILO;
    }

    /**
     * Realiza el proceso de rehabilitacion
     * @return String aclarando que se está rehabilitando el animal
     * o que no se puede rehabilitar
     */
    @Override
    public String rehabilitar() {
        String mensaje;
        if(getEstado() == EstadoSalud.EN_RECUPERACION){
            mensaje = "Rehabilitando a " + this.toString();
        } else {
            mensaje = this.toString() + " No se puede rehabilitar";
        }
        return mensaje;
    }

    @Override
    public String toString() {
        return super.toString() + " Mamifero{" + "peso=" + peso + '}';
    }
    
    
}
