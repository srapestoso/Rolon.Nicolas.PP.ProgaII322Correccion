package pp_proga2_322;

public class Ave extends Animal implements Liberable, Rehabilitable {
    private static final double COSTO_POR_METRO = 2.0;
    private final double envergaduraAlar;
    
    
    /**
     * Constructor de la clase Ave
     * @param codigo identificador del animal
     * @param nombre del animal
     * @param estado de salud del animal
     * @param envergaduraAlar del animal
     */
    public Ave(String codigo, String nombre, EstadoSalud estado,double envergaduraAlar) {
        super(codigo, nombre, estado);
        validarPositivo(envergaduraAlar);
        this.envergaduraAlar = envergaduraAlar;
    }
    
    /**
     * Calcula el costo diario del mamifero
     * @return double con el total
     */
    @Override
    public double costoDiario(){
        return envergaduraAlar * COSTO_POR_METRO;
    }

    /**
     * Realiza el proceso de rehabilitacion
     * @return String aclarando que se está rehabilitando el animal
     * o que no se puede rehabilitar
     */
    @Override
    public String rehabilitar() {
        String mensaje;
        if(getEstado() == EstadoSalud.EN_RECUPERACION){
            mensaje = "Rehabilitando a " + this.toString();
        } else {
            mensaje = this.toString() + " No se puede rehabilitar";
        }
        return mensaje;
    }
    
    /**
     * Realiza el proceso de liberacion
     * @return String aclarando que se está liberando el animal
     * o que no está apto para ser liberado
     */
    @Override
    public String liberar() {
        String mensaje;
        if(getEstado() == EstadoSalud.EN_RECUPERACION){
            mensaje = "Liberando a " + this.toString();
        } else {
            mensaje = this.toString() + " No está apto para ser liberado";
        }
        return mensaje;
    }

    @Override
    public String toString() {
        return super.toString() + " Ave{" + "envergaduraAlar=" + envergaduraAlar + '}';
    }
    
    
}
