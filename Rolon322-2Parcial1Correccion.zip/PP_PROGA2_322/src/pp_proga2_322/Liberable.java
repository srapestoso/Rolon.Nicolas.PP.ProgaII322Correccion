package pp_proga2_322;

public interface Liberable {
    
    /**
     * Realiza el proceso de liberacion del animal
     * @return Un mensaje indicando el resultado de la liberacion
     */
    String liberar();
    
}
